package Q3;

public interface Comparavel {

    public abstract boolean comparar(Object o, Object a);
}

