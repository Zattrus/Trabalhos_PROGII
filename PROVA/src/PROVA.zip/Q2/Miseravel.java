package Q2;

public class Miseravel extends Pessoa{

    public void mendinga() {
        System.out.println(super.getNome() + ", Voce e uma pessoa mendiga!!!");
    }
}
