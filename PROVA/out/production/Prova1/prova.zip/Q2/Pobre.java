package Q2;

public class Pobre extends Pessoa{

    public void trabalha() {
        System.out.println(super.getNome() + ", Voce precisa trabalhar!!!");
    }
}
