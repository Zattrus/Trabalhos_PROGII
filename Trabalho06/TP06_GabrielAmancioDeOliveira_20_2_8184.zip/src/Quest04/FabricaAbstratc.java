package Quest04;

import Quest04.Sanduiches;

public abstract class FabricaAbstratc {
    public abstract Sanduiches FactorySanduiches(String pao, String salada, String presenunto, String queijo);
}