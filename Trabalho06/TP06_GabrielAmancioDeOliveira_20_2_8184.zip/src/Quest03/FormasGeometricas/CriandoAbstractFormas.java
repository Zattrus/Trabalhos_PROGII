package Quest03.FormasGeometricas;

public abstract class CriandoAbstractFormas {
    public abstract CriandoFormulas FactoryFormaGeometricas(String nome, String lados, String vertices);
}
