package Quest06;

public abstract class FabricaAbstratc {
    public abstract Object FactorySanduiches(String pao, String salada, String presenunto, String queijo);
}